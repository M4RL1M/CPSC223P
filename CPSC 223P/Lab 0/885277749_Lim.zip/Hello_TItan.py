print("Hello")

date_of_birth = input("Date of birth (MM/DD/YYYY): ")
# print(date_of_birth)

name = input("Name: ")
# print(name)

languages_known = input("Number of Programming Languages Known: ")
# print(languages_known)

print("Performing a calculation: 3 x 2 + 5")
calculation = 3 * 2 + 5
print(calculation)